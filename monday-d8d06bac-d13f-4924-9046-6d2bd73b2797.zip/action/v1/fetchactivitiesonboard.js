const request = require('request');
module.exports = {

  name: "fetchactivitiesonboard",

  title: "Fetch Activities on Board",

  description: "",
  version: "v1",

  input:{
    title: "Fetchactivitiesonboard",
    type: "object",
    properties: {
      "boardID":{
      "title":"boardID",
      "type":"string",
      "displayTitle": "Board ID"

    }
  }
  },
  output: {
    title: "output",
  	type: "object",
  	properties: {

    }
  },

  mock_input:{},

  execute: function(input, output){
    request({
   url:'https://api.monday.com/v2',
   method: 'POST',
   headers: {
       "Content-type": "application/json",
       "Authorization": input.auth.api_key
   },
   body: JSON.stringify({"query" : "{boards(ids: "+input.boardID+") {activity_logs {id event data entity user_id}}}"}
   )
}, 
function (error,response, body) {
    
  if (error) {
    return output(error)

    }
	output(null,{responseBody:JSON.parse(body)});
}
)


} 
}
