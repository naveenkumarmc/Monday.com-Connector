const request = require('request');

module.exports = {
  name: "readboard",

  title: "Read Board",

  description: "",
  version: "v1",

  input:{
    title: "Readboard",
    type: "object",
    properties: {
      
      }

    },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "responseBody":{
        "title":"responseBody",
        "type":"string",
        "displayTitle": "Response Body"

      }

    }
  },
  mock_input:{},
  
  execute: function(input, output){
     request({
    url:'https://api.monday.com/v2',
    method: 'POST',
    headers: {
        "Content-type": "application/json",
        "Authorization": input.auth.api_key
    },
    body: JSON.stringify({"query" : "{boards(ids:752992226) {activity_logs {id event data}}}"}
    )
}, function (error,response, body) {
    
  if (response.statusCode >= 200 && response.statusCode < 400) {
    return output(body);
    } 
   output(null,{responseBody:JSON.parse(body)});
  }
  )

  
} 
}
